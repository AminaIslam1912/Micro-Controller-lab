#ifndef __GPIO_H
#define __GPIO_H

void GPIO_Init(void);
void GPIO_ON(int);
void GPIO_OFF(int);
#endif