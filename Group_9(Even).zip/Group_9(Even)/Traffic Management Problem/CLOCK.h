#ifndef __CLOCK_H
#define __CLOCK_H

#ifdef __cplusplus
extern "C" {
#endif

void initClock(void);

#ifdef __cplusplus
}
#endif

#endif