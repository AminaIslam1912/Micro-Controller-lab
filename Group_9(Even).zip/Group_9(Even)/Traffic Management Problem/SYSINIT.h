#ifndef SYSINIT_H
#define SYSINIT_H

#include "stm32f4xx.h"

void ms_delay(uint32_t ms);
void systemInit(void);

#endif
